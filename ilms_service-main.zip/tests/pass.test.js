const { expect } = require('chai');

describe('Pass', () => {
    it('should true be equal to true', () => {
        expect(true).to.equal(true);
    });
});
