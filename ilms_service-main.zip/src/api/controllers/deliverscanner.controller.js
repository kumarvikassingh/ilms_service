const httpStatus = require('http-status');
const deliverScannerService = require('../services/deliver_scanner_app/deliverscanner.service');
const cryptoService = require('../services/common/crypto.service');
var db = require('./../repository/mssql/sql_db.js');

exports.checkUserid = (req, res, next) => {
	try {
		
		deliverScannerService.CheckUserid(id, function (err, result) {
			if (err) {
				return err.message;
			} else {
				console.debug('deliverscanner.controller checkUserid response: ' + JSON.stringify(result));
				res.status(httpStatus.OK).json(result);
			}
		}

	} catch (e) {
		next(e);
	}
};