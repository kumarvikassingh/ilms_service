const repository = require('./mongo/mongo.repository');

module.exports = repository;
