var db = require('./../../repository/mssql/sql_db');

class DeliverScannerService {
    static async CheckUserid(payload, callback) {
        let style  = payload.style;
        let userId = payload.userId;
        let password = payload.password;

        finalQuery:String = '';

		try {
            if(style === 1) {
                finalQuery = 'Select * FROM pwdUsers_Scanners WHERE UserID= @userId and Active = 1';
            }
            else if (style === 2) {
                finalQuery = 'Select * FROM pwdUsers_Scanners WHERE UserID= @userId and Password = @password and Active = 1';
            }
            
			db.querySql(
				finalQuery,
				{ userId: userId, password: password },
				function (err, result) {
					console.debug('Result: ' + JSON.stringify(result.recordset));
					callback(err, result.recordset);
				}
			);
		} catch (e) {
			callback(e);
		}
	}
}
module.exports = DeliverScannerService;

