module.exports = {
	logs: 'dev',
};
