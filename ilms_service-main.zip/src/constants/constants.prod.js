module.exports = {
	logs: 'production',
};
